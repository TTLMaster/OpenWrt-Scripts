#!/bin/sh
echo -ne '\033]0;Управление скриптом автоматической перезагрузки при палеве Yota для ZTE MF910\007'

pause() {
	echo 'Нажмите Enter'
	read
}

echo 'Выберите действие:'
echo '1 - установить скрипт автоматической перезагрузки при палеве Yota'
echo '2 - удалить скрипт автоматической перезагрузки при палеве Yota'
echo '0 - выход'
echo -n ': '
read choice
echo

case $choice in
	1)
		scp ssh yotareboot root@192.168.0.1:/etc/init.d
		ssh root@192.168.0.1 chmod 755 /etc/init.d/yotareboot
		ssh root@192.168.0.1 ln -s /etc/init.d/yotareboot /etc/rcS.d/S99yotareboot
		;;
	2)
		ssh root@192.168.0.1 rm -rf /etc/init.d/yotareboot /etc/rcS.d/S99yotareboot
		;;
	0)
		exit
		;;
	*)
		echo 'Неверный ввод'
		echo
		pause
		exit
		;;
esac

echo
echo 'После нажатия Enter устройство будет перезагружено'
pause > /dev/null

ssh root@192.168.0.1 /sbin/reboot

echo
pause
