#!/bin/sh
echo -ne '\033]0;Управление скриптом блокировки палевных адресов Yota для модемов Huawei HiLink\007'

pause() {
	echo 'Нажмите Enter'
	read
}

echo 'Выберите действие:'
echo '1 - установить скрипт блокировки палевных адресов Yota'
echo '2 - удалить скрипт блокировки палевных адресов Yota'
echo '0 - выход'
echo -n ': '
read choice
echo

case $choice in
	1)
		scp ssh yotaban root@192.168.0.1:/etc/init.d
		ssh root@192.168.0.1 chmod 755 /etc/init.d/yotaban
		ssh root@192.168.0.1 ln -s /etc/init.d/yotaban /etc/rcS.d/S99yotaban
		;;
	2)
		ssh root@192.168.0.1 rm -rf /etc/init.d/yotaban /etc/rcS.d/S99yotaban
		;;
	0)
		exit
		;;
	*)
		echo 'Неверный ввод'
		echo
		pause
		exit
		;;
esac

echo
echo 'После нажатия Enter устройство будет перезагружено'
pause > /dev/null

ssh root@192.168.0.1 /sbin/reboot

echo
pause
