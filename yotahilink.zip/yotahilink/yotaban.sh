#!/bin/sh
echo -ne '\033]0;Управление скриптом блокировки палевных адресов Yota для модемов Huawei HiLink\007'

pause() {
	echo 'Нажмите Enter'
	read
}

adb connect 192.168.8.1:5555

echo
echo
echo 'Выберите действие:'
echo '1 - установить скрипт блокировки палевных адресов Yota'
echo '2 - удалить скрипт блокировки палевных адресов Yota'
echo '0 - выход'
echo -n ': '
read choice
echo

adb shell mount -o remount,rw /system /system

case $choice in
	1)
		adb push busybox yotaban /system/xbin
		adb shell chmod 755 /system/xbin/busybox /system/xbin/yotaban
		adb shell "busybox sed -i '/yotaban/d' /system/etc/autorun.sh"
		adb shell "echo -e '\n/system/xbin/yotaban &' >> /system/etc/autorun.sh"
		;;
	2)
		adb shell "busybox sed -i '/yotaban/d' /system/etc/autorun.sh"
		adb shell rm -rf /system/xbin/yotaban
		;;
	*)
		echo 'Неверный ввод'
		echo
		pause
		exit
		;;
esac

adb shell mount -o remount,ro /system /system

echo
echo 'После нажатия Enter устройство будет перезагружено'
pause > /dev/null

adb reboot

echo
pause
