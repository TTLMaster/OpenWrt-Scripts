#!/bin/sh
echo -ne '\033]0;Управление скриптом автоматической перезагрузки при палеве Yota для модемов Huawei HiLink\007'

pause() {
	echo 'Нажмите Enter'
	read
}

adb connect 192.168.8.1:5555

echo
echo
echo 'Выберите действие:'
echo '1 - установить скрипт автоматической перезагрузки при палеве Yota'
echo '2 - удалить скрипт автоматической перезагрузки при палеве Yota'
echo '0 - выход'
echo -n ': '
read choice
echo

adb shell mount -o remount,rw /system /system

case $choice in
	1)
		adb push busybox /system/xbin
		adb push yotareboot /system/xbin
		adb shell chmod 755 /system/xbin/busybox /system/xbin/yotareboot
		adb shell "busybox sed -i '/yotareboot/d' /system/etc/autorun.sh"
		adb shell "echo -e '\n/system/xbin/yotareboot &' >> /system/etc/autorun.sh"
		;;
	2)
		adb shell "busybox sed -i '/yotareboot/d' /system/etc/autorun.sh"
		adb shell rm -rf /system/xbin/yotareboot
		;;
	0)
		exit
		;;
	*)
		echo 'Неверный ввод'
		echo
		pause
		exit
		;;
esac

adb shell mount -o remount,ro /system /system

echo
echo 'После нажатия Enter устройство будет перезагружено'
pause > /dev/null

adb reboot

echo
pause
